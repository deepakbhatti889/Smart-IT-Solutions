$(document).ready(function() {
	$("#email").focus();
	
	$("#email_form").validate({
		rules: {
			email_1: {
				required: true,
				email: true
			},
			email_2: {
				required: true,
				email: true,
				equalTo: "#email_1"
			},
			password_1: {
				required: true,
				rangelength: [8, 12]
			},
			password_2: {
				required: true,
				equalTo: "#password_1"
			},
			first_name: {
				required: true
			},
			last_name: {
				required: true
			},
			account: {
				required: true
			},
			Phone: {
				rangelength: [10,10]
				
			},
			state: {
				required: true,
				rangelength: [2, 2]
			},
			zip: {
				required: true,
				digits: true,
				rangelength: [5, 5]
			}
		},
		messages: {
			email_2: {
				equalTo: "Please Re-Enter A Similar E-mail Address."
			},
			password_2: {
				equalTo: "Please Re-Enter A Similar Password."
			},
			password_1: {
				rangelength: "Kindly enter a Password with a lenght between 8 to 12."
			},
			
			Phone: {
				rangelength: "Please Enter A valid number"
			},
			account: {
				equalTo: "Please Select From One Of The Options Given."
			},
			state: {
				rangelength: "Kindly enter a 2-character state code."
			},
			zip: {
				rangelength: "Kindly enter a 5-digit zip code."
			}	
		}
	}); // end validate
}); // end ready
